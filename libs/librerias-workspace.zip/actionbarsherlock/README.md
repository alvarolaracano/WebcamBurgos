ActionBarSherlock Library
=========================

This folder contains the main library which should be linked against as an
Android library project in your application.

For more information see the "Including In Your Project" section of the
[usage page][1].






 [1]: http://actionbarsherlock.com/usage.html
